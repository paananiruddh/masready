# Patch: artifacts/masready/src/pages/features.tsx

## Step 1 — Add ClipboardCheck to the existing lucide-react import

Find the existing import line and add `ClipboardCheck`:

```tsx
import { Activity, UploadCloud, Fingerprint, Crosshair, PieChart, PackageCheck, Target, ShieldCheck, History, BookOpen, Database, ToggleLeft, CheckCircle2, AlertTriangle, Code2, ArrowRight, ClipboardCheck } from "lucide-react";
```

## Step 2 — Add to FEATURES array (after the `Trust Center` entry):

```tsx
{ title: "Environment Audit Checklist", icon: ClipboardCheck, desc: "52-point pre-migration assessment covering delivery intelligence, trust center compliance, patch impact, and AppPoints licence planning for Maximo 7.6.x to MAS Manage 9 transitions. Fully owned by MASReady." },
```
