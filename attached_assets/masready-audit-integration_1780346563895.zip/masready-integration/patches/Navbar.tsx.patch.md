# Patch: artifacts/masready/src/components/layout/Navbar.tsx

## In NAV_LINKS array, add after the Trust Center entry:

```tsx
{ href: "/audit-checklist", label: "Audit Checklist" },
```

So the array becomes:
```tsx
const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/mas9-power", label: "MAS9 Power Demo" },
  { href: "/features", label: "Features" },
  { href: "/adaptive-regression", label: "Adaptive Regression" },
  { href: "/data-modes", label: "Data Modes" },
  { href: "/trust", label: "Trust Center" },
  { href: "/audit-checklist", label: "Audit Checklist" },  // ← ADD THIS
  { href: "/architecture", label: "Architecture" },
  { href: "/media", label: "Media" },
  { href: "/demo-walkthrough", label: "Walkthrough" },
  { href: "/launch", label: "Launch" },
  { href: "/contact", label: "Contact" },
];
```

## Also check Design2Layout.tsx and Design3Layout.tsx
If either has their own NAV_LINKS or nav rendering, add the same entry.
