# Patch: artifacts/masready/src/App.tsx

## Add import (with existing imports, after `AdaptiveRegression`):

```tsx
import AuditChecklist from "@/pages/audit-checklist";
```

## Add route inside Design1Router <Switch> (after the `/adaptive-regression` route):

```tsx
<Route path="/audit-checklist" component={AuditChecklist} />
```
